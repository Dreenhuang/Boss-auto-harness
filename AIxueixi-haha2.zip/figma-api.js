const https = require('https');

const FIGMA_TOKEN = 'figd_t_HjP-nngrYJ7GqeDlYWF-SH6vouNH2vJnc7K2Ul';

function figmaRequest(path, method = 'GET', body = null) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'api.figma.com',
      path: `/v1${path}`,
      method: method,
      headers: {
        'X-Figma-Token': FIGMA_TOKEN,
        'Content-Type': 'application/json'
      }
    };
    
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(JSON.parse(data)));
    });
    
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

async function createFigmaFile() {
  console.log('Creating Figma file...');
  
  const result = await figmaRequest('/files', 'POST', {
    name: '小白AI产品经理训练营 - APP原型设计 (18页)'
  });
  
  console.log('File created:', result.name);
  console.log('File Key:', result.key);
  console.log('File URL:', `https://www.figma.com/file/${result.key}`);
  return result;
}

createFigmaFile().catch(console.error);
