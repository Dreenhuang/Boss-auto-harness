const https = require('https');

const FIGMA_TOKEN = 'figd_t_HjP-nngrYJ7GqeDlYWF-SH6vouNH2vJnc7K2Ul';

function figmaRequest(path, method = 'GET', body = null) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'api.figma.com',
      path: `/v1${path}`,
      method: method,
      headers: {
        'X-Figma-Token': FIGMA_TOKEN,
        'Content-Type': 'application/json'
      }
    };
    
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        console.log('Status:', res.statusCode);
        console.log('Response:', data.substring(0, 500));
        try { resolve(JSON.parse(data)); } 
        catch(e) { resolve(data); }
      });
    });
    
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

async function main() {
  console.log('=== Testing Figma API ===\n');
  
  console.log('1. Getting user info...');
  const user = await figmaRequest('/me');
  console.log('User:', JSON.stringify(user, null, 2));
}

main().catch(console.error);
