const https = require('https');

var FIGMA_TOKEN = 'figd_t_HjP-nngrYJ7GqeDlYWF-SH6vouNH2vJnc7K2Ul';

function figmaRequest(path, method, body) {
  method = method || 'GET';
  return new Promise(function(resolve, reject) {
    var options = {
      hostname: 'api.figma.com',
      path: '/v1' + path,
      method: method,
      headers: {
        'X-Figma-Token': FIGMA_TOKEN,
        'Content-Type': 'application/json'
      }
    };
    
    var req = https.request(options, function(res) {
      var data = '';
      res.on('data', function(chunk) { data += chunk; });
      res.on('end', function() {
        try { resolve({ status: res.statusCode, data: JSON.parse(data) }); } 
        catch(e) { resolve({ status: res.statusCode, data: data }); }
      });
    });
    
    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

async function main() {
  console.log('=== Figma Prototype Generator ===\n');
  
  // Step 1: Get user's teams
  console.log('1. Getting teams...');
  var teamsRes = await figmaRequest('/teams/me');
  
  if (teamsRes.data && teamsRes.data.teams && teamsRes.data.teams.length > 0) {
    var teamId = teamsRes.data.teams[0].id;
    console.log('   Found team:', teamsRes.data.teams[0].name);
    
    // Step 2: Get team projects
    console.log('\n2. Getting projects...');
    var projRes = await figmaRequest('/teams/' + teamId + '/projects');
    
    if (projRes.data && projRes.data.projects && projRes.data.projects.length > 0) {
      var projectId = projRes.data.projects[0].id;
      var projectName = projRes.data.projects[0].name;
      console.log('   Using project:', projectName);
      
      // Step 3: Create file in this project
      console.log('\n3. Creating design file...');
      var fileRes = await figmaRequest('/projects/' + projectId + '/files', 'POST', {
        name: '小白AI产品经理训练营 - 完整18页APP原型'
      });
      
      console.log('   Status:', fileRes.status);
      console.log('   Response:', JSON.stringify(fileRes.data).substring(0, 600));
      
      if (fileRes.status === 200 && fileRes.data && fileRes.data.key) {
        var key = fileRes.data.key;
        console.log('\n=== FILE CREATED SUCCESSFULLY! ===');
        console.log('File URL: https://www.figma.com/file/' + key);
        return key;
      }
    } else {
      console.log('   No projects found. Response:', JSON.stringify(projRes.data).substring(0, 300));
    }
  } else {
    console.log('   Teams response:', JSON.stringify(teamsRes.data).substring(0, 400));
    
    // Try alternative: create in drafts using different endpoint
    console.log('\nTrying drafts folder...');
    var draftRes = await figmaRequest('/me/files', 'POST', { 
      name: '小白AI产品经理训练营 - 完整18页APP原型' 
    });
    console.log('Drafts response:', JSON.stringify(draftRes.data).substring(0, 600));
  }
}

main().catch(console.error);
